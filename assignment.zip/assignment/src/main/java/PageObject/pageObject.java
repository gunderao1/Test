package PageObject;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

public class pageObject {
	private WebDriver driver;
	private WebDriverWait wait;
	private Actions act;
	private Robot robot;

	public pageObject(WebDriver driver) throws IOException, AWTException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		ExtentCucumberAdapter.addTestStepLog(" page object Initialized");
		wait = new WebDriverWait(driver, 50);
		act = new Actions(driver);
		robot = new Robot();

	}

	private final By revenueCalculatorLink = By.linkText("Revenue Calculator");
	private final By slider = By.xpath("//input[@aria-orientation=\"horizontal\"]");
	private final By textField = By.id(":r0:");
	private final By totalReimbursementHeader = By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month']"); 
	private final By totalReimbursementHeaderValue = By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month']/following-sibling::p");

	public void navigateToRevenueCalculatorPage() {
		waitForElement(revenueCalculatorLink).click();
		 ExtentCucumberAdapter.addTestStepLog("clicked on revenue calculator link");
	
	}

	public void scrollToSliderSection() {

		scrollToElement(waitForElement(slider));
	}

	public void adjustSlider(int value) throws InterruptedException {
		setSliderValue(value);
		verifyValue(slider, value);
		//
	}

	public void validateTextFieldValue(int expectedValue) {
		verifyValue(textField, expectedValue);
	}

	public void updateTextField(int value) throws InterruptedException {
		setTextFieldValue(value);
		verifyValue(textField, value);
	}

	public void validateSliderValue(int expectedValue) {
		verifyValue(slider, expectedValue);
	}

	public void selectCPTCodes(String... codes) {
		for (String code : codes) {
			selectCheckbox(code);
		}
	}

	public void validateReimbursement(String expectedValue) {
		scrollToElement(waitForElement(totalReimbursementHeader));
		String headerText = waitForElement(totalReimbursementHeaderValue).getText();
		Assert.assertTrue(headerText.contains(expectedValue));
	}

	// Utility Methods
	private WebElement waitForElement(By locator) {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	private void scrollToElement(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	private void setSliderValue(int value) throws InterruptedException {
		waitForElement(slider);

		WebElement sliderHandle = driver.findElement(By.cssSelector("input[data-index='0']")); // Replace with your
																								// actual locator

		Actions actions = new Actions(driver);

		while (true) {

			String currentWidth = sliderHandle.getAttribute("value");
			int currentValue = Integer.parseInt(currentWidth);

			System.out.println("Current Width: " + currentValue);

			if (currentValue == 820) {
				System.out.println("Target width reached: " + currentValue);
				break;
			}

			int distance = 820 - currentValue;
			int offset = distance > 50 ? 20 : 2;
			int direction = distance > 0 ? 1 : -1;
			actions.clickAndHold(sliderHandle).moveByOffset(offset * direction, 0).release().perform();
			Thread.sleep(100);
		}

		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void setTextFieldValue(int value) throws InterruptedException {
		WebElement field = waitForElement(textField);
		act.moveToElement(field).doubleClick().doubleClick().sendKeys(Keys.BACK_SPACE).build().perform();
		field.sendKeys(String.valueOf(value));
		driver.findElement(By.xpath("//h4[text()='Medicare Eligible Patients']")).click();
	}

	private void verifyValue(By locator, int expectedValue) {
		WebElement element = waitForElement(locator);
		String actualValue = element.getAttribute("value");
		Assert.assertEquals(String.valueOf(expectedValue), actualValue);
	}

	private void selectCheckbox(String code) {

		wait.until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//p[text()='" + code + "']/following-sibling::label/span/input[@type='checkbox']")));

		WebElement checkboxLocator = driver.findElement(
				By.xpath("//p[text()='" + code + "']/following-sibling::label/span/input[@type='checkbox']"));
		
		ExtentCucumberAdapter.addTestStepLog("selected required checkboxes successfully");
		if (!checkboxLocator.isSelected()) {
			checkboxLocator.click();
			ExtentCucumberAdapter.addTestStepLog("selected checkbox of  :" + code);
		}
	}
}
