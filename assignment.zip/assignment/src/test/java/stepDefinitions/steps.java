package stepDefinitions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import PageObject.pageObject;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;




public class steps {
	private Properties prop;
	private FileInputStream fis1;
	private WebDriver driver;
	private pageObject pageobjectPage;
	
	@After("@tag")
	public void teardown(Scenario scenario) throws InterruptedException, IOException {
	
		    
		
		if (scenario.isFailed()) {
			TakesScreenshot scrShot = ((TakesScreenshot) driver);
			final byte[] screenshot = scrShot.getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", scenario.getName());
			File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
			File DestFile = new File(prop.getProperty("user.dir") + "\\test-output\\screenshots\\failed.jpg");
			FileUtils.copyFile(SrcFile, DestFile);
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.close();
		} else 
		{
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.close();
		}
	}
 
	
	
	  
	@Before("@tag")
	public void i_initialize_drivers_for_Access_module_automation(Scenario scenario) throws Throwable {
		prop = new Properties();
		 fis1 = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\data.properties");
		prop.load(fis1);
	    WebDriverManager.chromedriver().setup();
	    driver = new ChromeDriver();
		System.out.println("Driver Initialized");
		ExtentCucumberAdapter.addTestStepLog("Driver Initialized");
		pageobjectPage = new pageObject(driver);
		
		driver.manage().window().maximize();
	}
	@Given("I am on the FitPeo homepage")
	public void i_am_on_the_FitPeo_homepage() throws AWTException {
		 driver.get(prop.getProperty("URL")); 
		 ExtentCucumberAdapter.addTestStepLog("Entered URL of Fitpeo");
		 Assert.assertEquals(driver.getCurrentUrl(), "https://fitpeo.com/");
		 ExtentCucumberAdapter.addTestStepLog("Verified");
	        driver.manage().window().maximize();
	       
	}

	@When("I navigate to the Revenue Calculator page")
	public void i_navigate_to_the_Revenue_Calculator_page() throws AWTException {
		pageobjectPage.navigateToRevenueCalculatorPage();
		 Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			for (int i=0;i<10;i++){

				robot.keyPress(KeyEvent.VK_MINUS);
				robot.keyRelease(KeyEvent.VK_MINUS);
				System.out.println("zooming out");
			}
			robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	@Then("I scroll down to the slider section")
	public void i_scroll_down_to_the_slider_section() {
		pageobjectPage.scrollToSliderSection();
		ExtentCucumberAdapter.addTestStepLog("Scrolled down till slider section");
	}

	@When("I adjust the slider to {int}")
	public void i_adjust_the_slider_to(Integer int1) throws InterruptedException {
		pageobjectPage.adjustSlider(int1);
		ExtentCucumberAdapter.addTestStepLog("Slider value adjusted to "+ int1 );
	}

	@Then("the bottom text field should display {int}")
	public void the_bottom_text_field_should_display(Integer int1) {
		pageobjectPage.validateTextFieldValue(int1);
		ExtentCucumberAdapter.addTestStepLog("the bottom text field displayed slided value successfully");
	}

	@When("I update the text field with value {int}")
	public void i_update_the_text_field_with_value(Integer int1) throws InterruptedException {
		pageobjectPage.updateTextField(int1);
		ExtentCucumberAdapter.addTestStepLog("Updated the text field value successfully");
	}

	@Then("the slider should reflect the value {int}")
	public void the_slider_should_reflect_the_value(Integer int1) {
		pageobjectPage.validateSliderValue(int1);
		ExtentCucumberAdapter.addTestStepLog("Slider moved as per given value in the text field successfully");
	}

	@When("I select the CPT codes {string}, {string}, {string}, and {string}")
	public void i_select_the_CPT_codes_CPT_CPT_CPT_and_CPT(String int1, String int2, String int3, String int4) {
		pageobjectPage.selectCPTCodes(int1,int2,int3,int4);
		ExtentCucumberAdapter.addTestStepLog("selected required checkboxes successfully");
	}

	@Then("the Total Recurring Reimbursement should show {string}")
	public void the_Total_Recurring_Reimbursement_should_show(String string) {
		pageobjectPage.validateReimbursement(string);
		ExtentCucumberAdapter.addTestStepLog("Value is updated as expected");
	
	}


	
}
